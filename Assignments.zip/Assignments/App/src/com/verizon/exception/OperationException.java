package com.verizon.exception;

public class OperationException {
	OperatorException(String msg){
		
	}

}
