package com.verizon.ui;

public class Source {
	public static void main(String[] args) {
		Activity activity=new Activity("Hello","Welcome","+");
		Source
	}

}
