package julySeventh;

public class Hierarchy {
	public static void main(String[] args) {
		new Hierarchy().exceptionHandling();
	}
	
	void exceptionHandling() {
		for (int i =2; i>=0; i*=i ) {
			System.out.println(i);
		}
	}

}
