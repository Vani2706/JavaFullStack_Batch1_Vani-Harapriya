package julySeventh;

import java.util.Scanner;

public class JavaStrings {
String palindrome;
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the string");
		String palindrome = scan.next();
		JavaStrings call = new JavaStrings();
		String rev = "";
		for (int i = palindrome.length()-1; i >= 0; i--) {
			rev += palindrome.charAt(i);
		}
//		System.out.println(palindrome);
		if (rev.equals(palindrome))
			System.out.println("Palindrome string");
		else
			System.out.println("Not a palindrome string");
	}

}
