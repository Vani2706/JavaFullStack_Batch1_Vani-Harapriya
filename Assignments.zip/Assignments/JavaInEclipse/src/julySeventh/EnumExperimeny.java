package julySeventh;

public class EnumExperimeny {
	public static void main(String[] args) {
		new MetroTicket().getMenu();	
		}

}

class MetroTicket{
	void getMenu() {
		System.out.println("These are the the routes of Hyderabad metro");
		MetroRoutes[] route = MetroRoutes.values();
		for (MetroRoutes values:route) {
			System.out.println(values + " with frequency of " + values.frequency);
		}
	}		
}
enum MetroRoutes{
	RED ("3 mins"), BLUE ("2 mins"), GREEN ("6 mins");
	
	String frequency;
	
	MetroRoutes(String frequency){
		System.out.println("");
		this.frequency = frequency;
	}
	public String getFrequency() {
		return this.frequency;
	}
}