package julySeventh;

import java.util.Scanner;

public class CreatingSplit {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Scanner scannext = new Scanner(System.in);
		
		System.out.println("Enter the string");
		String input = scan.nextLine();
		
		System.out.println("Enter the delimiter");
		String delim = scannext.nextLine();
		
		CreatingSplit call = new CreatingSplit();
		call.mySplit(input, delim);
		
	}
	void mySplit(String accept, String delim) {
		String cut = accept ,store = accept;
		int length=accept.length()-1;
		for (int i =0; i<= length; i++) {
			if(cut.contains(delim)) {
				int temp = cut.indexOf(delim);
				System.out.println(cut.substring(0,temp));
				cut=cut.substring(temp+1,cut.length());
		}
		}
		System.out.println(cut);
	}
}

		
		
		
		
		
		
		
		
		
		
		
		
		
//		String temp = "";
//		int delimlen = delim.length();
//		for(int i = 0; i<=accept.length()-1; i++) {
//			temp = "";
//			int j;
//			for (j= i; j <=accept.indexOf(accept.charAt(i)); j++) {
//				temp += accept.charAt(j);
//				}
//			if (temp.equals(delim)) {
//				int tempindex = ;
//				System.out.println(accept.substring(tempindex, i));
//			}
//		}
//				
//			}
//		}


