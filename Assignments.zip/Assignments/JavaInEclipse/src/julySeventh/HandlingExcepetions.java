package julySeventh;

import java.util.InputMismatchException;
import java.util.Scanner;

public class HandlingExcepetions {
	public static void main(String[] args) {
		new HandlingExcepetions().countingNumbers();
	}
	
	void countingNumbers() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the length of the array");
		try{
			int length = scan.nextInt();
			int arr[] = new int[length];
			System.out.println("Array was created");
		}catch (InputMismatchException ref) {
			System.out.println("Just enter a number");
		}
		System.out.println("Outside");
		
		
	}

}
