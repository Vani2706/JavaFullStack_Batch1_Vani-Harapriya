package Hereditary;

public class Constructors {

	public static void main(String[] args) {
		new StudentMarks();
	}

}

class Student{
	Student(String fullmarks){
		System.out.println("Student constructor executed");
	}
	
}
class StudentMarks extends Student{
	public StudentMarks(){
		this("");
		System.out.println("StudentMarks executed");
	}
	public StudentMarks(String finalmarks){
		super(finalmarks);
		System.out.println("Final marks were obtained");
	}
	
}
