package Hereditary;

public class Overidden {
	public static void main(String[] args) {
		Car call = new Car();
		call.steeringWheel();
		
	}
}
	
	class Car{
		void body(){
			System.out.println("The car has a body");
		}
		final void steeringWheel(){
			System.out.println("The car has a fixed steering wheel");
			}
		void wheels() {
			System.out.println("The car has wheels");
		}
		private void lock() {
			System.out.println("The car has a lock");
		}
	}
	class Honda extends Car{
		void keys() {
			System.out.println("Honda has its own keys");
		}
	}
	class Civic extends Honda{
		void accelaration() {
			System.out.println("Honda Civic has its own acceleration");
		}
		@Override
		void body() {
			System.out.println("Honda Civic has a wide body");
		}

}
