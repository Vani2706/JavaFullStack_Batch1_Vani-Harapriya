package assignmentsix;

import java.util.Scanner;

public class RevArray {
	String arr = "";
	public static void main(String[] args) {
		RevArray call=new RevArray();
		call.getSorted();
		
	}
	
	void getSorted() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the length of array");
		int arrlen = scan.nextInt();
		String array[] = new String [arrlen];
		
		System.out.println("Enter the letters");
		for (int i = 0; i<arrlen; i++) {
			array[i]=scan.next();
		}
		for(int i = (arrlen-1); i>=0; i--) {
			System.out.println(array[i]);
		}
	}
}

