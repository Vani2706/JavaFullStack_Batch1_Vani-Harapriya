import java.util.Scanner;

public class JavaInEclipse {

	public static void main(String[] args) {
		Addition call = new Addition();
		call.add();
}
}

class Addition {
	void add() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter two numbers");
		int a,b;
		a=scan.nextInt();
		b=scan.nextInt();
		int sum=a+b;
		System.out.println("The sum is: " + sum);
		}
}

	