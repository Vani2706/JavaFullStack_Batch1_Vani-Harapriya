package julyNineth;

public class ThrowsThrowAndMOre {
	public static void main(String[] args) {
		
	}

}

class Broken{
 		void System.out.println();
	}
}