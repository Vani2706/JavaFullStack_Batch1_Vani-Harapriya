package julyNineth;

import java.util.Scanner;
import java.util.TreeSet;

public class MenuDriven {
	public static void main(String[] args) {
		int menudriver = 1;
		do {
		Scanner scanmenu = new Scanner(System.in);
		System.out.println("Welcome, please enter '1' for adding new details, '2' for searching existing users, '3' for viewing all present details or '4' for sorting present details & to exit press '0'");
		menudriver = scanmenu.nextInt();
		switch(menudriver) {
		case(1):{
			new DataBase().entryIntoDatabase();
			break;
		}
		case(2):{
			new DataBase().SearchingInDatabase();
			break;
		}
		case(3):{
			new DataBase().PrintingDatabase();
			break;
		}
		case(4):{
			System.out.println("Please select your sorting choice betweenn the following by typing:");
			System.out.println("'a' for first name");
			System.out.println("'b' for last name");
			System.out.println("'c' for country");
			System.out.println("'d' for age");
			String sortingdriver = scanmenu.next();
			switch(sortingdriver) {
			case("a"):{
				new PersonalDetails().compareToFirstName(null);
				break;
			}
			case("b"):{
				new PersonalDetails().compareToSecondName(null);
				break;
			}
			case("c"):{
				new PersonalDetails().compareToCountry(null);
				break;
			}
			case("d"):{
				new PersonalDetails().compareToAge(null);
				break;
			}
			}
			break;
		}
		}
		
		}while(menudriver !=0);
		
		
	}

}


class PersonalDetails implements Comparable<PersonalDetails>{
	private String firstname;
	private String secondname;
	private String country;
	private String age;

		
		public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getSecondname() {
		return secondname;
	}

	public void setSecondname(String secondname) {
		this.secondname = secondname;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

		@Override
		public String toString() {
			return "Name=" + this.firstname + " " + this.secondname+ "Country=" + this.country + ", Age=" + this.age;
		}
		
		public PersonalDetails(String firstname, String secondname, String country, String age) {
			super();
			this.firstname = firstname;
			this.secondname = secondname;
			this.country = country;
			this.age = age;
		}
		public PersonalDetails() {
			// TODO Auto-generated constructor stub
		}

		public int compareToAge (PersonalDetails o) {
			return this.getAge().compareTo(o.getAge());
		}
		public int compareToCountry (PersonalDetails o) {
			return this.getCountry().compareTo(o.getCountry());
		}
		public int compareToFirstName (PersonalDetails o) {
			return this.getFirstname().compareTo(o.getFirstname());
		}
		public int compareToSecondName (PersonalDetails o) {
			return this.getSecondname().compareTo(o.getSecondname());
		}

		@Override
		public int compareTo(PersonalDetails o) {
			// TODO Auto-generated method stub
			return 0;
		}
		}



class DataBase{
	Scanner scan = new Scanner(System.in);
	TreeSet<PersonalDetails> data = new TreeSet<PersonalDetails>();
	String tempfirstname;
	String tempsecondname;
	String tempname;
	String tempcountry;
	String tempage;
	void entryIntoDatabase() {
		tempfirstname = null;
		tempsecondname = null;
		tempcountry = null;
		tempage = null;
		System.out.println("Please enter the name ");
		tempname = scan.nextLine();
		if(tempname.contains(" ")) {
			int whitespace = tempname.indexOf(" ");
			tempfirstname = tempname.substring(0, whitespace);
			tempsecondname = tempname.substring(whitespace);
		}else {
			tempfirstname = tempname;
			tempsecondname = "-";
		}
		System.out.println("Please enter the country");
		tempcountry = scan.nextLine();
		System.out.println("Please enter the age");
		tempage = scan.nextLine();
		data.add(new PersonalDetails(tempfirstname, tempsecondname,  tempcountry, tempage));
		System.out.println("Entry added");
		data.forEach(System.out::println);
	}
	
	void SearchingInDatabase() {
		System.out.println("Enter the name of the person who you want to look up");
		String search = scan.nextLine();
		for (PersonalDetails find : data ) {
			if (search.equals(find)) {
				System.out.println("The person has been found, and their details are:");
				new PersonalDetails().toString();
			}else
				System.out.println("Person not found");
		}
	}
	void PrintingDatabase() {
		System.out.println("The data base is as follows: ");
		for (PersonalDetails run : data) {
			System.out.println(run);
		}
	}
		
		
	}
	

	