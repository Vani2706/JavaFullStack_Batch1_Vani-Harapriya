
package julyNineth;
public class FunctionsInJava {

	public static void main(String[] args) {
		

	}

}

static void PrintingDetailsOfWaterBottle(Bottle Bottle) {
	System.out.println("The water bottle is of the brand: " +bottle.brand + " and its capacity is: " + bottle.capacity + "ml");
	
}
