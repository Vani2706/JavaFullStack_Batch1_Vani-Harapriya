package julyNineth;

public class AnonymousClasses {
	public static void main(String[] args) {
		new AllStatics() {

			@Override
			public void callerTune() {
				System.out.println(
						"This anonymous class is used to avoid creating a sublclass of an interface when you want to call an object of the said interface...");

			}
		}.callerTune();
	}
}

interface AllStatics {
	void callerTune();
}
