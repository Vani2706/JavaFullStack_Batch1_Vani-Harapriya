package julyNineth;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;
public class Person {
	public Person(String string, int i, String string2) {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int opt;
		Scanner sc =new Scanner(System.in);
		Person person1 = new Person("Dhoni",43,"India");
		System.out.println(person1);
		Person person2 = new Person("Jadeja",37,"India");
		System.out.println(person2);
		ArrayList<Person> listOfPerson =new ArrayList<>();
				System.out.println("Options in the menu are: ");
				System.out.println("1.Add new person");
				System.out.println("2.View records");
				System.out.println("3.Search By Name");
				System.out.println("4.Sort By a)Name b)Age c)Country");
				System.out.println("5.Exit");
		do{
				System.out.println("Enter option: ");
			    opt =sc.nextInt();
			switch(opt)
			{
			case 1:	
				System.out.println("Enter person Details: ");
				String name =sc.next();
				Integer age = sc.nextInt();
				String country =sc.next();
				listOfPerson.add(new Person(name, age, country));
				System.out.println(listOfPerson);
				break;
			case 2:
				listOfPerson.forEach(System.out::println);
				break;
			case 3:
				System.out.println("Search By Person Name: ");
				String searchByName =sc.next();
				for(int i=0; i <= listOfPerson.size()-1; i++)
				{
					if(listOfPerson.get(i).name().equals(searchByName))
					{
						System.out.println(listOfPerson.get(i));
					}
				}
				break;
			case 4:
				System.out.println("Sort by: a)Name b)Age c)Country");
				char option = sc.next().charAt(0);
				switch(option)
				{
					case 'a':
						listOfPerson.sort(new sortByFirstName());
						listOfPerson.forEach(System.out::println);
						break;
					case 'b':
						listOfPerson.sort(new sortByAge());
						listOfPerson.forEach(System.out::println);
						break;
					case 'c':
						listOfPerson.sort(new sortByCountry());
						listOfPerson.forEach(System.out::println);
						break;
				}
				break;
			case 5:
				System.exit(0);
				break;
			default:
				System.out.println("Invalid option");
			}
		}while(opt!=5);
	}

	public String name() {
		// TODO Auto-generated method stub
		return null;
	}

	public String age() {
		// TODO Auto-generated method stub
		return null;
	}

	public String one() {
		// TODO Auto-generated method stub
	}

	public String country() {
		// TODO Auto-generated method stub
		return null;
	}
}
record Entry(String name,Integer age,String country) {
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + ", country=" + country + "]";
	}
}
class sortByFirstName implements Comparator<Person>{
	@Override
	public int compare(Person firstPerson, Person secondPerson) {
		return firstPerson.name().compareTo(secondPerson.name());

	}
}
class sortByAge implements Comparator<Person>{
	@Override
	public int compare(Person firstPerson, Person secondPerson) {
		return firstPerson.age().compareTo(secondPerson.age());
	}
}
class sortByCountry implements Comparator<Person>{
	@Override
	public int compare(Person firstPerson, Person secondPerson) {
		return firstPerson().compareTo(secondPerson.country());
	}

	private String firstPerson() {
		// TODO Auto-generated method stub
		return null;
	}
}