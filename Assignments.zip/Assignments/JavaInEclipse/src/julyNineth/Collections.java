package julyNineth;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.LinkedList;
import java.util.Scanner;

public class Collections {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter '1' for array list or '2' for linked list");
		int drive = scan.nextInt();
		if (drive == 1)
			new Marks().listOfMarks();
		else if (drive == 2)
			new UsingLinkedLists().declaration();
		else
			System.out.println("Enter either only 1 or 2");
	}

}

class Marks {
	ArrayList marks = new ArrayList();
	
	void listOfMarks() {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the length of array");
		int length = scan.nextInt();
		
		System.out.println("Enter the marks");
		try {
			
		for (int i = 0; i<length; i++) {
				marks.add(scan.nextInt());
				}	
		
		printingMarks();
			}catch (InputMismatchException io) {
				System.out.println("Please enter marks only in digit form");
			}
	}
	
	void printingMarks(){
		System.out.println("The marks are as follows: ");
		
		for (Object print: marks){
			if (print instanceof Integer) {	
				System.out.println(print);
			}
		}
	}
}

class UsingLinkedLists{
	void declaration() {
		LinkedList names = new LinkedList();
		
		names.add("Spiderman");
		names.add("Iron Man");
		names.add("Hulk");
		
		names.forEach(System.out::println);
		
		names.remove(2);
		System.out.println("The list after removal of hulk:");
		System.out.println("");
		names.forEach(System.out::println);
	}
}


