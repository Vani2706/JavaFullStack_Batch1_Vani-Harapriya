package julyNineth;

public class JavaBeans {
	public static void main(String[] args) {
		BottleOfWater callone = new BottleOfWater("Kinley", 1000, "Magnesium and Zinc");
		System.out.println(callone);
		BottleOfWater calltwo = new BottleOfWater("Bisleri", 2500, "None (It is a cheap brand...)");
		System.out.println(calltwo);
	}

}

class BottleOfWater{
	private String brand;
	private Integer capacity;
	private String addedminerals;
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public Integer getCapacity() {
		return capacity;
	}
	@Override
	public String toString() {
		return "BottleOfWater [Brand=" + brand + ", Capacity=" + capacity + "ml, Added Minerals:" + addedminerals + "]";
	}
	public void setCapacity(Integer capacity) {
		this.capacity = capacity;
	}
	public String getAddedminerals() {
		return addedminerals;
	}
	public void setAddedminerals(String addedminerals) {
		this.addedminerals = addedminerals;
	}
	public BottleOfWater(String brand, int capacity, String addedminerals) {
		this.brand=brand;
		this.capacity=capacity;
		this.addedminerals=addedminerals;
	}
	
}
