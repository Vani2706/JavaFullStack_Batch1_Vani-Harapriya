package julyNineth;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.TreeSet;

public class SortingAndMore {

	public static void main(String[] args) {
		MobilePhone phone = new MobilePhone(29999, "7T" , "OnePlus");
		
		ArrayList<MobilePhone> list = new ArrayList<>();
		list.add(new MobilePhone(34999, "Note 2", "Samsung"));
		list.add(new MobilePhone(72999, "14", "iPhone"));
		list.add(phone);
		Collections.sort(list);
		list.forEach(System.out::println);	
	}

}

class MobilePhone implements Comparable<MobilePhone>{
	private Integer price;
	private String model;
	private String company;
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	
	public MobilePhone(int price, String model, String company) {
		super();
		this.price = price;
		this.model = model;
		this.company = company;
	}
	@Override
	public String toString() {
		return "Price of the phone is: " + price + ", its model being " + model + ", from the company " + company;	
	}
	public int compareTo (MobilePhone o) {
		return this.getModel().compareTo(o.getModel());
	}
}