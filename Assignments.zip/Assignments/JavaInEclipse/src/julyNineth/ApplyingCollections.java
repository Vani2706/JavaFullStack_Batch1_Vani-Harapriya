package julyNineth;

import java.util.ArrayList;
import java.util.Comparator;

public class ApplyingCollections {

	public static void main(String[] args) {

		Developer developer = new Developer("ManiDeepika", "Java, HTML");

		ArrayList<Developer> listOfDevelopers = new ArrayList<>();

		listOfDevelopers.add(developer);
		listOfDevelopers.add(new Developer("Dhruv", "Java, CSS, JS"));
		listOfDevelopers.add(new Developer("Pranav", "C, C++"));

//					listOfDevelopers.forEach(System.out::println);

		System.out.println("Currently we have the following developers registered:");
		for (Developer theDeveloper : listOfDevelopers) {
			System.out.println(theDeveloper.getName() + " with skills : " + theDeveloper.getSkills());
		}

//					
		listOfDevelopers.sort((firstDeveloper, secondDeveloper) -> firstDeveloper.getName().compareTo(secondDeveloper.getName()));

					//Sort a
					//listOfDevelopers.sort((firstDeveloper, secondDeveloper) -> firstDeveloper.getSkills().compareTo(secondDeveloper.getSkills()));

		System.out.println("After sorting, list:");
		for (Developer theDeveloper : listOfDevelopers) {
			System.out.println(theDeveloper.getName()+ ", having the next level skills in " + theDeveloper.getSkills());
			
		}
	}

}

// Functional Interfaces

// class Developer implements Comparable<Developer>{
class Developer {
	private String name;
	private String skills;

	public Developer(String name, String skills) {
		super();
		this.name = name;
		this.skills = skills;
	}

	public Developer() {

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	@Override
	public String toString() {
		return "Hi there I am a Developer [name=" + name + ", skills=" + skills + "]";
	}

//				@Override
//				public int compareTo(Developer o) {
//					
////					Define your sorting logic here
//					return o.getName().compareTo(this.getName());
//				}

}