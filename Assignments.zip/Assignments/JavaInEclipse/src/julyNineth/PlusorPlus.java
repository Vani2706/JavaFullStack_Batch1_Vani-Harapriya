package julyNineth;

public class PlusorPlus {
	public static void main(String[] args) {
		int a =5;
		System.out.println(++a);
		a=5;
		System.out.println(a++);
		System.out.println(a);
	}

}
