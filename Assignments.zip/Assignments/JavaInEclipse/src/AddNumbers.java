import java.util.Scanner;

public class AddNumbers {
	int numOne, numTwo, sum;
	public static void main(String[] args) {
		new AddNumbers().input();
		
	}
	void input() {
		Scanner scan = new Scanner(System.in);
		AddNumbers enter = new AddNumbers();
		System.out.println("Enter the two numbers");
		numOne= scan.nextInt();
		numTwo= scan.nextInt();
		add();
	}
	void add() {
		sum=numOne + numTwo;
		print();
	}
	void print() {
		System.out.println("The addition of the numbers is: "+sum);
	}
}
	
