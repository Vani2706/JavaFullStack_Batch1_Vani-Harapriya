package JulyTwelfth;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class LatestAssignment {
	Long temphighestincome = 0L;
	String tempname = "";
	public static void main(String[] args) {
		List <Person> listOfPersons = List.of(
				new Person("Karthik", Gender.MALE, 21500L),
				new Person("Fatima", Gender.FEMALE, 24800L),
				new Person("Anshuman",Gender.MALE, 23000L),
				new Person("Dhruv", Gender.MALE, 34900L),
				new Person("Gayathri", Gender.FEMALE, 33600L)
				);
//		new LatestAssignment().highestIncome(listOfPersons);
//		new LatestAssignment().listOfMales(listOfPersons);
//		new LatestAssignment().lengthOfNames(listOfPersons);
//		new LatestAssignment().endsInN(listOfPersons);
//		new LatestAssignment().femaleMaxIncome(listOfPersons);
	//	new LatestAssignment().sortingTheList(listOfPersons);
		
		listOfPersons.stream()
		.map(person -> person.name())
		.mapToInt(String::length)
		.forEach(System.out::println);
		
		listOfPersons.stream()
		.sorted(Comparator.comparing(Person::income).reversed())
		.collect(Collectors.toList())
		.forEach(System.out::println);
		
		boolean anyMatch = listOfPersons.stream()
				.anyMatch(person -> person.name().endsWith("i"));
				
				System.out.println(anyMatch);
		
	}
		void highestIncome(List <Person> listOfPersons) {
		for (Person person : listOfPersons) {
			if(person.income()>temphighestincome) {
				temphighestincome = person.income();
				tempname = person.name();
			}
			}
		System.out.println("The person with the highest income is: " + tempname + " and their income is " +temphighestincome);

		}
		void listOfMales(List <Person> listOfPersons) {
		System.out.println("The list of males is as follows: ");
		for (Person male : listOfPersons) {
			if(male.gender().equals(Gender.MALE))
					System.out.println(male.name());
	}
		}
		void lengthOfNames(List <Person> listOfPersons) {
	System.out.println("The lenght of each name is: ");
	for (Person lenghtofname : listOfPersons) {
		int length = lenghtofname.name().length();
		System.out.println(lenghtofname.name() + ", " + length);
}
		}
		void endsInN(List <Person> listOfPersons) {
	System.out.println("The names which end in n are: ");
		for(Person endsin : listOfPersons) {
			if (endsin.name().endsWith("n")) {
				System.out.println(endsin.name());
			}
		}
		}
		void sortingTheList(List<Person> listofPersons) {
			listofPersons.sort((firstEmp, secondEmp) -> firstEmp.name().compareTo(secondEmp.name()));
			listofPersons.forEach(System.out::println);
		}
		
	void femaleMaxIncome(List<Person> listOfPersons) {
		Long temphighestfemaleincome = 0L;
		String tempfemalename = "";
		for (Person femalemaxincome : listOfPersons) {
			if (femalemaxincome.gender().equals(Gender.FEMALE) && femalemaxincome.income()>temphighestfemaleincome) {
					temphighestfemaleincome = femalemaxincome.income();
					tempfemalename = femalemaxincome.name();
				
		}
	}
		System.out.println("The female with the highest income is: " + tempfemalename + " with income: " + temphighestfemaleincome);
		}
	
//	
//	listOfPersons.stream()
//	.map(person -> person.name())
//	.mapToInt(String::length)
//	.forEach(System.out::println);
	
//	Or using a predicate for returning a boolean
//	listOfPersons.stream()
//	.filter(person -> person.gender().equals(Gender.MALE))
//	.collect(Collectors.toList())
//	.forEach(System.out::println);
	
//	Or lets sort
//	listOfPersons.stream()
//	.sorted(Comparator.comparing(Person::income).reversed())
//	.collect(Collectors.toList())
//	.forEach(System.out::println);
	
//	All match
//	boolean allMatch = listOfPersons.stream()
//	.allMatch(person -> person.name().endsWith("i"));
//	
	//System.out.println(allMatch);
//	
	//Any match
//	boolean anyMatch = listOfPersons.stream()
//	.anyMatch(person -> person.name().endsWith("i"));
//	
//	System.out.println(anyMatch);
//	
////	none match
//	boolean noneMatch = listOfPersons.stream()
//	.noneMatch(person -> person.name().endsWith("z"));
////	
//	System.out.println(noneMatch);
	
//	using Min
//	listOfPersons.stream()
//	.min(Comparator.comparing(Person::income))
//	.ifPresent(System.out::println);
//	
////	using Max
//	listOfPersons.stream()
//	.max(Comparator.comparing(Person::income))
//	.ifPresent(System.out::println);
//	
//	
////	Grouping
//	listOfPersons.stream()
//	.collect(Collectors.groupingBy(Person::gender))
//	.forEach((gender, listByGender) -> {
//		System.out.println(gender);
//		listByGender.forEach(System.out::println);
//	});
//	
////	Chaining
//	listOfPersons.stream()
//	.filter(thePerson -> thePerson.gender().equals(Gender.FEMALE))
//	.min(Comparator.comparing(Person::income))
//	.map(Person::name)
//	.ifPresent(System.out::println);

}


record Person (String name, Gender gender, Long income) {}

enum Gender {MALE, FEMALE, PNTS}n