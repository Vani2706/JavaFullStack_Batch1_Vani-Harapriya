package JulyTwelfth;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

record Learner(Integer id, String name){}

public class DBMSInJava {

	public static final String DB_URLTOCONNECT = "jdbc:mysql://localhost:3306/july_twelfth";

	public static final String DB_USERNAME = "root";

	public static final String DB_PASSWORD = "";
	
	String qry;
	
	static  Connection dbConnection;
	
	static Statement theStatement;
	
	static ResultSet resultSet;

	public static void main(String[] args) {

		try {
//			1. Load the Driver
			Class.forName("com.mysql.cj.jdbc.Driver");

//			2. Try to establish the connection
			dbConnection = DriverManager.getConnection(DB_URLTOCONNECT, DB_USERNAME, DB_PASSWORD);
			
//			Get a reference to the Statment object
			theStatement = dbConnection.createStatement();
			
			Scanner scan = new Scanner(System.in);
			
			System.out.println("Enter id of learner:");
			int id = scan.nextInt();
			scan.nextLine();
			System.out.println("Enter name of learner:");
			String name = scan.nextLine();
			
			//new DBMSInJava().addNewLearner(new Learner(id, name));
			//new DBMSInJava().updateAnEntry(new Learner(id,name));
			new DBMSInJava().removeAnEntry(new Learner(id, name));
			
//			new DbConnect().getAllLearners();
//			new DbConnect().getLearnerDetailsById(new Scanner(System.in).nextInt());


		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Problems while connecting to the db : " + e.getMessage());
		}

	}
	
	
//	Fetch all learners from the table:learner
	void getAllLearners() {

		try {
			
			//Write the query to fetch all learners
			qry = "select * from learner";
			

			
//			Get a reference to the ResultSet object
			resultSet = theStatement.executeQuery(qry);
			
//			Traverse through the results
			while(resultSet.next()) {
				System.out.println(resultSet.getString("learner_name")
						+ " with ID : "
						+ resultSet.getInt("id"));
			}
			
//			Close the connection
			dbConnection.close();
			
			
			
		} catch (SQLException e) {
			System.out.println("Issues while reading from table  : " + e.getMessage());
		}
	}
	
	
	
//	Fetch A leaerner by id
	void getLearnerDetailsById(Integer id) {
		qry = "select * from learner where id = '" + id + "'";
		
		try {
			resultSet = theStatement.executeQuery(qry);
			
			while(resultSet.next()) {
				System.out.println(resultSet.getString("learner_name"));
			}
			
			
		} catch (SQLException e) {
			System.out.println("Issues while reading : " + e.getMessage());
		}	
		
	}
	
//	Add a new Learner
	void addNewLearner(Learner learner) {
		qry = "insert into learning_with_java values('" 
	+ learner.id() + "', '" 
	+ learner.name() + "')";
		
		try {
			if(theStatement.executeUpdate(qry) > 0)
				System.out.println("New learner details added...");
			else
				System.out.println("Learner details not saved, please try again later...");
			
			
			
			
		} catch (SQLException e) {
			System.out.println("Issues while adding a new learner : " + e.getMessage());
			
			
		}
		
	}
//  Updating an entry in the table
	
	void updateAnEntry(Learner learner) {
		qry = "update learning_with_java set learner_name = '" + learner.name()+ "'  where id = '" + learner.id() + "'";
		
		try {
			if(theStatement.executeUpdate(qry) > 0)
				System.out.println("Learner details updatesa...");
			else
				System.out.println("Learner details not updated, please try again later...");
			
			
			
			
		} catch (SQLException e) {
			System.out.println("Issues while updating a new learner : " + e.getMessage());
	
	
	
	}
	}
	void removeAnEntry(Learner remove) {
		qry ="delete from learning_with_java where id = ?";
		try {
		PreparedStatement stmt = dbConnection.prepareStatement(qry);
		stmt.setInt(1, remove.id());
		System.out.println("Deleted");
	}catch(SQLException e) {
		System.out.println("Undeleted, problem is: " + e.getMessage());
	}
}
}
	
	



