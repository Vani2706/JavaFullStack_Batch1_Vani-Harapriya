package com.jdbc;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcApp1 {

	public static void main(String[] args) throws ClassNotFoundException,SQLException {
		//step1
		Class.forName("oracle.jdbc.driver.OracleDriver");
		//step2
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","oracle123");
		System.out.println("Connection successfull!!!");
		
		Statement st=con.createStatement();
		
		//st.executeUpdate("create table plan_details(pid number primary key)");
		st.executeUpdate("insert into plan_details values(3)");
		ResultSet rs=st.executeQuery("Select*from plan_details");
		while(rs.next()) {
			System.out.println(rs.getString(1));
		}

	}

}
