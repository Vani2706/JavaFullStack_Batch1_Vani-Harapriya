package com.training.dhruv.devops;

import org.testng.annotations.Test;

public class CarGears {
	@Test
	public void NoGear() {
		System.out.println("No gear selected");
	}
	@Test(priority=2)
	public void FirstGear() {
	System.out.println("In first gear");
	}
	@Test(priority=3)
	public void SecondGear() {
		System.out.println("In second gear");
	}

}
