package com.training.dhruv.devops;

import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByName;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Something {
	
	public static void main(String[] args) {
		
//		System.setProperty("webdriver.chrome.driver", "C:\\Users\\verizon\\Downloads\\chromedriver_win32\\chromedriver.exe");
//		WebDriver driver = new ChromeDriver();
//		driver.get("http://www.verizon.com");
//		String titleGetter = driver.getTitle();
//		System.out.println("The given title of the web page is: " + titleGetter);
//		String getSource = driver.getPageSource();
//		System.out.println("The source of the page is: " + getSource);
//		driver.quit();
		new Something().Google();
		}
	void Google() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\verizon\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.google.com");	
		driver.findElement(By.name("q")).sendKeys("Vattakailu");
		
		for (int i = 1; i<=10; i++)
			driver.findElement(By.name("q")).sendKeys(Keys.BACK_SPACE);
		
		driver.findElement(By.name("q")).sendKeys("Verizon location");
		driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
		
		List <WebElement>element = driver.findElements(By.tagName("a"));
		int count = element.size();
		
		System.out.println("The number of links are: " + count);
		driver.quit();
	}
}


