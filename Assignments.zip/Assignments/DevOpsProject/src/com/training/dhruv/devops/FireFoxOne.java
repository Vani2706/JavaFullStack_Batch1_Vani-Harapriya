package com.training.dhruv.devops;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class FireFoxOne {

   public static void main(String[] args) throws Exception {

  System.setProperty("webdriver.chrome.driver",

       "C:\\Users\\verizon\\Downloads\\chromedriver_win32\\chromedriver.exe");

   WebDriver driver = new ChromeDriver();

   driver.get("https://in.bookmyshow.com/");

//   System.out.println(driver.getTitle());
   
   Thread.sleep(10000);

   driver.findElement(By.xpath("//*[@id=\"modal-root\"]/div/div/div/div[2]/ul/li[4]/div/div/img")).click();
   
   Thread.sleep(10000);

   driver.findElement(By.linkText("//*[@id=\"https://in.bookmyshow.com/hyderabad/movies/oppenheimer/ET00347867-1\"]/div/div[2]/div/img")).click();

   

   driver.findElement(By.xpath("//*[@id=\"page-cta-container\"]/button/div")).click();

   Thread.sleep(1000);

   driver.findElement(By.xpath("//*[@id=\"super-container\"]/div[2]/div/div[2]/div/div/ul/li[1]/section[2]/div")).click();

   Thread.sleep(1000);

   driver.findElement(By.xpath("//*[@id=\"venuelist\"]/li[34]/div[2]/div[2]/div[2]/a/div/div[1]")).click();
   

   Thread.sleep(1000);
   
   driver.findElement(By.xpath("//*[@id=\"btnPopupAccept\"]")).click();

   // how to enter the date month and year in drop down box

//   WebElement day1=driver.findElement(By.id("day"));
//
//   day1.sendKeys("8");
//
//   Thread.sleep(2000);
//
//   WebElement mon1=driver.findElement(By.id("month"));
//
//   mon1.sendKeys("28");
//
//   Thread.sleep(2000);
//
//   WebElement year1=driver.findElement(By.id("year"));
//
//   year1.sendKeys("2024");
//
//   Thread.sleep(2000);
//
//   Select select = new Select(day1);
//
//   select.selectByVisibleText("31");
//
//   Thread.sleep(1000);
//
//   select.selectByValue("6");
//
//   Thread.sleep(1000);
//
//   select.selectByIndex(5);
//
//   Thread.sleep(1000);

// boolean v1=var2.isDisplayed();

// System.out.println(v1);

  /* List<WebElement> f1 =driver.findElements(By.xpath("//input[@type='radio']"));

   System.out.println("Number of radio buttons"+f1.size());

   for(WebElement var1:f1)

   {

    System.out.println(var1.getAttribute("value"));

   }

   */

   }

 }
