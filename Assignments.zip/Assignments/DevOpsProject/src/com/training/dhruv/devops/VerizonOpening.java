package com.training.dhruv.devops;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
//import org.testng.AfterClass;
//import org.testng.BeforeClass;
//import org.testng.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class VerizonOpening {
	WebDriver driver;
	@BeforeClass
	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\verizon\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
	
	}
	@Test
	public void executeBrowser(){
		driver.get("http://verizon.com");
		String title = driver.getTitle();
		System.out.println("The given title of the website" + title);
		AssertJUnit.assertEquals(title, "Google India");
		
	}
	@AfterClass()
	public void closeBrowser() {
		System.out.println("Exit the application");
		driver.quit();
	}
	

}
