package com.training.dhruv.devops;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CheckingTickets {
	public static void main(String[] args) throws Exception {

		  System.setProperty("webdriver.chrome.driver",

		       "C:\\Users\\verizon\\Downloads\\chromedriver_win32\\chromedriver.exe");

		   WebDriver driver = new ChromeDriver();
		   
		   driver.navigate().to("https://in.bookmyshow.com/buytickets/oppenheimer-hyderabad/movie-hyd-ET00347867-MT/20230729");
		   
		   do {
		   Thread.sleep(30000);
		   driver.navigate().refresh();
		   
		   }while(1 != 0);
	}

}
