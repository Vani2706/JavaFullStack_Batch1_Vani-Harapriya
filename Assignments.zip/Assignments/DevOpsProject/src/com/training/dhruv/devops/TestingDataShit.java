package com.training.dhruv.devops;

import org.testng.annotations.Test;


public class TestingDataShit {
	@Test(priority=2)
	public void OpenChrome() {
		System.out.println("Chrome has been opened");
	}
	@Test(priority=1)
	public void OpenEdge() {
		System.out.println("Edge has been opened");
	}
	@Test(priority=3)
	public void OpenFirefox() {
		System.out.println("Firefox has been opened");
	}
	

}
