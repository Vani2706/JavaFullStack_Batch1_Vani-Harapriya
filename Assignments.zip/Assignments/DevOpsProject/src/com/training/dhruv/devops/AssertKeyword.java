package com.training.dhruv.devops;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import junit.framework.Assert;

public class AssertKeyword {
	WebDriver driver;
	@BeforeClass
	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver", "‪C:\\Users\\verizon\\Downloads\\geckodriver-v0.33.0-win-aarch64\\geckodriver.exe");
		driver = new FirefoxDriver();
	
	}
	@Test
	public void executeBrowser(){
		driver.get("http://flipkart.com");
		String title = driver.getTitle();
		System.out.println("The given title of the website" + title);
		Assert.assertEquals(title, "Google India");
		
	}
	@AfterClass()
	public void closeBrowser() {
		System.out.println("Exit the application");
		driver.quit();
	}
	

}
