package com.verizon;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CalculatorTest2 {
	Calculator c;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.out.println("Testing class started");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		System.out.println("Testing ended");
	}

	@BeforeEach
	void setUp() throws Exception {
		System.out.println("Testing each case method started");
		
	}

	@AfterEach
	void tearDown() throws Exception {
		System.out.println("Test case object  is tear down");
	}

	@Test
	void testSum() {
		//fail("Not yet implemented");
	}

	@Test
	void testDiff() {
		//fail("Not yet implemented");
	}

	@Test
	void testProduct() {
		//fail("Not yet implemented");
	}

	@Test
	void testDiv() {
		//fail("Not yet implemented");
	}

}
