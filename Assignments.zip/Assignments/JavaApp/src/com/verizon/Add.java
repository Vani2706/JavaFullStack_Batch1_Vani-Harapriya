package com.verizon;

public class Add {
	int sum(int a,int b) {
		return a+b;
	}
}
