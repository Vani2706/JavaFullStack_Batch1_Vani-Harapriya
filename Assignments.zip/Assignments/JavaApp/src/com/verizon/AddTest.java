package com.verizon;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AddTest {

	@Test
	void testSum() {
		Add a=new Add();
		assertEquals(10,a.sum(6, 4));
		//fail("Not yet implemented");
	}

}
