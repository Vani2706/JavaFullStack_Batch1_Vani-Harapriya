package com.verizon;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectClasses({ AddTest.class, CalculatorTest.class, CalculatorTest2.class, LoanTest.class })
public class AllTests {

}
