package com.verizon;

public class Customer {

	public Integer getBalance() {
		// TODO Auto-generated method stub
		return 8760;
	}


}
