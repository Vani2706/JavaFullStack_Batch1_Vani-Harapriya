package com.verizon;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CustomerTest {

	@Test
	void test() {
		Customer c=new Customer();
		assertEquals(c.getBalance(),8760);
		//fail("Not yet implemented");
	}

}
