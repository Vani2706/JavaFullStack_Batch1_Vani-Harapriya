package com.verizon;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculatorTest {

	@Test
	void testSum() {
		Calculator c=new Calculator();
		assertEquals(5,c.sum(2,3));
		//fail("Not yet implemented");
	}

	@Test
	void testDiff() {
		Calculator c=new Calculator();
		assertEquals(-1,c.diff(2,3));
		//fail("Not yet implemented");
	}

	@Test
	void testProduct() {
		Calculator c=new Calculator();
		assertEquals(6,c.product(2,3));
		//fail("Not yet implemented");
	}

	@Test
	void testDiv() {
		Calculator c=new Calculator();
		assertEquals(0,c.div(2,3));
		//fail("Not yet implemented");
	}

}
