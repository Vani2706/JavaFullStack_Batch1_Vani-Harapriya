package com.verizon;

public class Account {
	
	public Integer withdraw() {
		return 4000;
	}
	public Integer deposit() {
		return 7860;
	}

}
