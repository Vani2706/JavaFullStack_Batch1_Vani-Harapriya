package com.verizon;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AccountTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
		Account t = new Account();
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testWithdraw() {
		Account t = new Account();
		assertEquals(t.withdraw(),4000);
		//fail("Not yet implemented");
	}

	@Test
	void testDeposit() {
		Account t = new Account();
		assertEquals(t.deposit(),7860);
		
		//fail("Not yet implemented");
	}

}
