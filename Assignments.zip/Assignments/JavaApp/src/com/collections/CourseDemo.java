package com.collections;

import java.util.List;

public class CourseDemo {

	public static void main(String[] args) {
		Course c1=new Course(10,"RD Sharma",999.00);
		Course c2=new Course(20,"Angular",899.00);
		
		CourseService cs=new CourseServiceImpl();
		System.out.println(cs.addCourse(c1));
		System.out.println(cs.addCourse(c2));
		
		List<Course> returnedList=cs.listCourses();
		for(Course c:returnedList)
     	System.out.println(c);
		
		System.out.println(cs.deleteCourse(20));
		
		System.out.println(cs.updateCourse(10));
		
		List<Course> returnedList1=cs.listCourses();
		for(Course c:returnedList1)
			System.out.println(c);
		

	}

}
