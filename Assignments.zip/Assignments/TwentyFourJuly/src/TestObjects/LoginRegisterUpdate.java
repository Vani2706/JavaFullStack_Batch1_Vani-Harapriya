package TestObjects;

public class LoginRegisterUpdate {
	
	//login update module

}
