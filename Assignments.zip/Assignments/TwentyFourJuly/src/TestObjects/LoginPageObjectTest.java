package TestObjects;

import org.testng.annotations.Test;

import PageObject.*;

public class LoginPageObjectTest {
	@Test
	public void testCaseOne() {
		
		LoginPageObj objectOne = new LoginPageObj();
		objectOne.openBrowser();
		objectOne.createUsername();
		objectOne.createUsername();
		objectOne.loginSubmit();
		objectOne.closeBrowser();
		
		LogInUpdateMobileNumber objectTwo = new LogInUpdateMobileNumber();
		objectTwo.updateEmail();
		objectTwo.closePage();
	}
	
	
	
	
	
}
