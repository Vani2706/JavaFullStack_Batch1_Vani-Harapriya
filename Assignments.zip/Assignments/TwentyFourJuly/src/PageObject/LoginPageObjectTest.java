package PageObject;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class LoginPageObjectTest {

	@Test

	public void Testcase1() throws InterruptedException

	{

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Admin\\Downloads\\chromedriver_win32\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();

		driver.get("https://demo.opencart.com/");

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		LoginPageObj.openBrowser().click();

		LoginPageObj.LoginLink(driver).click();

		LoginPageObj.CreateUserName(driver).sendKeys("email@email.com");

		LoginPageObj.CreatePassword(driver).sendKeys("email@123");

		LoginPageObj.LoginSubmit(driver).click();

		LoginPageObj.OpenAccount(driver).click();

		Thread.sleep(1000);

		LoginUpdateMobileNumber.Registelink(driver).click();

		Thread.sleep(1000);

		LoginUpdateMobileNumber.UpdateEmail(driver).sendKeys("email@123");

		System.out.println("updated register link for the email");

		Thread.sleep(3000);

		driver.quit();

	}

}
