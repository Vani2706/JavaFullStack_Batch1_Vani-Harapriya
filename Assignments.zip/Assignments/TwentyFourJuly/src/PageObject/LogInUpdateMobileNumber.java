package PageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LogInUpdateMobileNumber {
	static WebDriver driver;
	
	public static void registerLink() {
		//driver.findElement(By.xpath("//*[@id=\"input-email\"]"));
		WebElement register = driver.findElement(By.linkText("Register"));
		register.click();
	}
	
	public static void updateEmail() {
		WebElement updatedEmail = driver.findElement(By.xpath("//*[@id=\\\"input-email\\\"]"));
		updatedEmail.sendKeys("Ottakailu@bmail.com");		
	}
	
	public static void closePage() {
		driver.navigate().back();
	}
}
