package PageObject;

import java.awt.Button;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPageObj {
	
	WebDriver driver;
	
	public void openBrowser() {
		driver.get("https://demo.opencart.com/");
		driver.findElement(By.xpath("//*[@id=\"top\"]/div[2]/div[2]/ul/li[2]/div/a/span"));
		driver.findElement(By.xpath("//*[@id=\"top\"]/div[2]/div[2]/ul/li[2]/div/ul/li[2]/a"));
		
	}
	
	public void createUsername() {
		WebElement userUsername = driver.findElement(By.xpath("//*[@id=\"input-email\"]"));
		userUsername.sendKeys("userOne@Object.com");
	}
	
	public void createPassword() {
		WebElement userPassword = driver.findElement(By.xpath("//*[@id=\"input-email\"]"));
		userPassword.sendKeys("user123");
	}
	
	public void loginSubmit() {
		WebElement loginSubmission = driver.findElement(By.xpath("//*[@id=\"form-login\"]/button"));
		loginSubmission.click();
		
	}
	
	public void closeBrowser() {
		driver.quit();
	}
	
	
	

}
