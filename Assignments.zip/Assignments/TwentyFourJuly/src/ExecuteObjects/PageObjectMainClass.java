package ExecuteObjects;

public class PageObjectMainClass {
	public static void main(String[] args) {
		
	}
}
