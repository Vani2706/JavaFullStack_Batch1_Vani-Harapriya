package com.verizon.controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.verizon.model.Plan;

@RestController
public class PlanController {
	
@GetMapping("/plan")      //display
public String getPlanDetails() {
	return "Plan1 details: 45 days,90 minutes........";
}
@PostMapping("/plan")     //add plan
public Plan getPlanDetails(@RequestBody Plan plan) {
	//plan=new Plan(101,"Independence Day plan",30);
	return plan;
	
}

@PutMapping("/plan")      //update
public String updatePlanDtails() {
	return "plan1 is updated.";
}

@DeleteMapping("/plan")    //delete
public String deletePlanDetails() {
	return "Plan1 is deleted.";
}
	
}

