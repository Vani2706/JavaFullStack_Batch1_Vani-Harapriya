package com.verizon.dao;

public class PlamDao {

}
