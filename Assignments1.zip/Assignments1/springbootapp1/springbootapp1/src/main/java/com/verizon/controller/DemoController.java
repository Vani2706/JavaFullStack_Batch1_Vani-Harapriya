package com.verizon.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.verizon.Springbootapp1Application;

public class DemoController {

	public static void main(String[] args) {
		SpringApplication.run(Springbootapp1Application.class, args);
	}
	@GetMapping("/Welcome")     // url of the web service
	public String getMessage() {
		return "Welcome to Springboot";
	}
	@GetMapping("/get/{pname}")
	public String getProductDetails(@PathVariable("pname") String pname) {
		return "My product is compact Mobile "+pname;
	}
	@GetMapping("/get/{name}/{phoneno}")
	public String getPersonDetails(@PathVariable("name")String name, @PathVariable("phoneno") String phoneno) {
		return "My name is "+name+" and my phone number is "+phoneno;
	}
}
