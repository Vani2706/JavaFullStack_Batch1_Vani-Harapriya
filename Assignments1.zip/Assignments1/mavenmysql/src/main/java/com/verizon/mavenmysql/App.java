package com.verizon.mavenmysql;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
//    	FranchiseCricketer franchiseCricketer = new FranchiseCricketer("VK", "MI");
//    	franchiseCricketer.play();
    	
//    	Load the context
    	ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("OttakyleConfig.xml");
    	
//    	Get a reference to the bean
//    	FranchiseCricketer franchiseCricketer =  context.getBean("fk", FranchiseCricketer.class);
//    	
//    	GullyCricket gullyCricket = context.getBean("gully", GullyCricket.class);
////    	Call methods on it
//    	gullyCricket.play();
//    	
    	
    	AnnotationsBall annotationsball = context.getBean("annotationsBall", AnnotationsBall.class);
    	
    	annotationsball.play();
  
    	
    }
}
