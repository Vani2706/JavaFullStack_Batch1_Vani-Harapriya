package com.verizon.mavenmysql;

public interface Cricketer {
	void play();
}
