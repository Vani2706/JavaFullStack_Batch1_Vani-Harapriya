package com.verizon.mavenmysql;

public class GullyCricket implements Cricketer{
	private String rules;
	private String maxballs;
	
	
	public GullyCricket() {}
	
	public String getRules() {
		return rules;
	}
	public void setRules(String rules) {
		this.rules = rules;
	}
	public String getMaxballs() {
		return maxballs;
	}
	public void setMaxballs(String maxballs) {
		this.maxballs = maxballs;
	}
	@Override
	public String toString() {
		return "GullyCricket [rules=" + rules + ", maxballs=" + maxballs + "]";
	}
	public GullyCricket(String rules, String maxballs) {
		super();
		this.rules = rules;
		this.maxballs = maxballs;
	}
	@Override
	public void play() {
		
		System.out.println("These are the rules of gully cricket: "+ this.rules + " and  "+ this.maxballs);
	}
	

}
