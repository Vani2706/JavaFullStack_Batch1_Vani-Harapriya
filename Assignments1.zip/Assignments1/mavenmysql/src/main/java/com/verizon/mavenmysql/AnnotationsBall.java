package com.verizon.mavenmysql;

import org.springframework.stereotype.Component;
@Component()
public class AnnotationsBall implements Cricketer{
	private GullyCricket gullycricket;
	private String rules;
	private String maxballs;
	public AnnotationsBall() {
		// TODO Auto-generated constructor stub
	}

	public AnnotationsBall(GullyCricket gullycricket) {
		super();
		this.gullycricket = gullycricket;
	}

	@Override
	public String toString() {
		return "AnnotationsBall [gullycricket=" + gullycricket + "]";
	}

	public GullyCricket getGullycricket() {
		return gullycricket;
	}
    
	public void setGullycricket(GullyCricket gullycricket) {
		this.gullycricket = gullycricket;
	}

	public String getRules() {
		return rules;
	}

	public void setRules(String rules) {
		this.rules = rules;
	}

	public String getMaxballs() {
		return maxballs;
	}

	public void setMaxballs(String maxballs) {
		this.maxballs = maxballs;
	}

	@Override
	public void play() {
		System.out.println("These are the rules for the ball: ");
		System.out.println(this.rules+ " " + this.maxballs);
		// TODO Auto-generated method stub
		
	}
	

}
