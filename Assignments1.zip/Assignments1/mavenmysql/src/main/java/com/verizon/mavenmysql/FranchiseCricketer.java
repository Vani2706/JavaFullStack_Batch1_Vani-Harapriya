package com.verizon.mavenmysql;

public class FranchiseCricketer implements Cricketer {

	private String name;
	private String franchise;
	
	private Contact contact;

	
	public FranchiseCricketer() {
		// TODO Auto-generated constructor stub
	}

	public FranchiseCricketer(String name, String franchise, Contact contact) {

		this.name = name;
		this.franchise = franchise;
		this.contact = contact;
	}

//	public void setName(String name) {
//		System.out.println("Setter for name called...");
//		this.name = name;
//	} 
//
//	public void setFranchise(String franchise) {
//		System.out.println("Setter for franchise called...");
//		this.franchise = franchise;
//	}

	@Override
	public void play() {
		System.out.println("Hi there I am " + this.name + " and I play for " + this.franchise);
		System.out.println("And I can be reached on : ");
		
		System.out.println(contact);

//		System.out.println("Franchise Cricketer's play()...");

	}
}
