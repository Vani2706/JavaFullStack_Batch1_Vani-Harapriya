package com.verizon.test;

import org.testng.annotations.Test;

public class SumTest {
  @Test(priority=2)
  public void f1() {
	  System.out.println("done");
  }
  @Test(priority=1)
  public void f2() {
	  System.out.println("done");
  }
  
}
