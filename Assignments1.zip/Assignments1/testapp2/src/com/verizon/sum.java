package com.verizon;

public class sum {
	 public Integer addnum(){
	        int num1 = 5;
	        int num2 = 10;
	        return num1+num2;   
	    }
}