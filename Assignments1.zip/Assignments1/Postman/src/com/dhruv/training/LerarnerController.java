package com.dhruv.training;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import jakarta.websocket.server.PathParam;

@RestController
public class LerarnerController {

	ArrayList<Learner> listOfLearners = new ArrayList<>(Arrays.asList(
			new Learner("Swathi", "Java, SQL", 67),
			new Learner("Hema", "Java", 561),
			new Learner("Harini", "SQL, Java", 212),
			new Learner("Yamana", "SQL", 313)
			));
	
	@GetMapping("/learners")
	List<Learner> getAllLearners(){
		return listOfLearners;
	}
	
	@GetMapping("/learners/{id}")
	Learner getLearnerById(@PathVariable Integer id) {
		return listOfLearners.stream()
				.filter(ref -> ref.id().equals(id))
				.findFirst()
				.get();
	}
	
	@PostMapping("/learners")
	void addNewLearner(@RequestBody Learner learner) {
		listOfLearners.add(learner);
	}
	
	@PutMapping("/learners/{id}")
	void updateLearnerDetails(@RequestBody Learner learner,@PathVariable Integer id) {
		listOfLearners.set(
				listOfLearners.indexOf(
				listOfLearners.stream()
				.filter(ref -> ref.id().equals(id)).findFirst().get()
				), learner);
	}
	
	@DeleteMapping("/learners/{id}")
	void deleteLearnerDetails(@PathVariable Integer id) {
		listOfLearners.remove(
				listOfLearners.indexOf(
				listOfLearners.stream()
				.filter(ref -> ref.id().equals(id)).findFirst().get()
				));
	}
	
	
	
	
	
	
	
	
	
	
	
}
