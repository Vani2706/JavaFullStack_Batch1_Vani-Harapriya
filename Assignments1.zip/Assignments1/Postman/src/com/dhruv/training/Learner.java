package com.dhruv.training;

public record Learner(String name, String skills, Integer id) {

}
