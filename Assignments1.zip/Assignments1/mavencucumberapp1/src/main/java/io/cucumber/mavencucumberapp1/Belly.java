package io.cucumber.mavencucumberapp1;

public class Belly {
	public void eat(int cukes) {
		System.out.println("Step started");
	}
    public void waitStep() {
    	System.out.println("Waiting after step1");
    }
    public void endProcess() {
    	System.out.println("All steps completed");
    }
}

