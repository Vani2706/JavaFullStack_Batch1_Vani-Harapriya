package com.verizon.mavencucumberapp1;

import io.cucumber.java.en.*;
import io.cucumber.mavencucumberapp1.Belly;

import static org.junit.jupiter.api.Assertions.*;

public class StepDefinitions {

    @Given("I have {int} cukes in my belly")
    public void I_have_cukes_in_my_belly(int cukes) {
    	Belly belly=new Belly();
    }

    @When("I wait 1 hour")
    public void allStepDefinitionsAreImplemented() {
    Belly belly=new Belly();
    belly.waitStep();
    }

    @Then("my belly should growl")
    public void theScenarioPasses() {
    	Belly belly=new Belly();
    	belly.endProcess();
    }

}
