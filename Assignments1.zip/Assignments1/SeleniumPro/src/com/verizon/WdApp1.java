package com.verizon;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import junit.framework.Assert;

public class WdApp1 {
	 WebDriver driver;  
		

		@Test
		void test() {
			  driver= new ChromeDriver();

		         driver.get("https://www.browserstack.com/");

		         Assert.assertEquals(driver.getTitle(), " App & Cross Browser Testing Platform | BrowserStack");

		         driver.quit();
		}

}
