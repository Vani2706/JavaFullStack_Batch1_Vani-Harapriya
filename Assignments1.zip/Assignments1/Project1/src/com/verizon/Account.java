package com.verizon;

public class Account {

	int acNumber;
	String name;
	double balance;
	static String bname = "hitech city building 10";

	Account() {
		acNumber = 999;
		name = "Sita";
		balance = 20000.00;
	}

	public Account(int acNumber, String name) {
		super();
		this.acNumber = acNumber;
		this.name = name;
	}

	public Account(int acNumber, double balance) {
		super();
		this.acNumber = acNumber;
		this.balance = balance;
	}

	public Account(int acNumber, String name, double balance) {
		super();
		this.acNumber = acNumber;
		this.name = name;
		this.balance = balance;
	}

	void deposit(int amt) {
		balance += amt;

	}

	double withdraw(int amt) {
		balance -= amt;
		return balance;

	}

	double getBalance() {
		return balance;
	}

	public static void main(String[] args) {

	}

}
