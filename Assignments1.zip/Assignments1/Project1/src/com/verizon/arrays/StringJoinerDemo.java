package com.verizon.arrays;

import java.util.StringJoiner;

//String Joiner
public class StringJoinerDemo {

	public static void main(String[] args) {
		StringJoiner joinNames= new StringJoiner(",");   //passing comma(,) as delimeter
		joinNames.add("Rahul");
		joinNames.add("Raju");
		joinNames.add("Peter");
		joinNames.add("Raheem");
		System.out.println(joinNames);
		System.out.println(joinNames.length());
		StringJoiner s1=new StringJoiner("-");
		s1.add("java");
		s1.add("python");
		System.out.println(joinNames.merge(s1));

	}

}
