package com.verizon.arrays;

import java.util.Arrays;
import java.util.List;

public class ArrayDemo {

	public static void main(String[] args) {
		int a[] = {4,5,3,6,7,8,2,3,1};
		for(int x:a)
			System.out.print(x+" ");
		System.out.println();
		Arrays.sort(a);
		
		for(int x:a)
			System.out.print(x+" ");
		System.out.println();
		
		int b[]=new int[5];
		
		Arrays.fill(b, 89);
		for(int x:b)
			System.out.print(x+" ");
		System.out.print(Arrays.compare(a, b));
		System.out.println();
		
		List<Integer> list=Arrays.asList(5,6,3,2,1,7,8);
		System.out.println("=================for each method with lambda====================");
		list.forEach(x->System.out.print(x));
		System.out.println();
		System.out.println("================for each method with reference===================");
		list.forEach(System.out::print);
		System.out.println();
		List list1=Arrays.asList("shaym",56,89.7);
		list1.forEach(System.out::print);
			
	}

}
