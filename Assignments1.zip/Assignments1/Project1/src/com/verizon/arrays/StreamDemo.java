package com.verizon.arrays;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class StreamDemo {

	public static void main(String[] args) {
		List<Integer> list=Arrays.asList(5,7,6,9,3,2,5,4,1,8);
		list.forEach(x->System.out.print(x+" "));
		
		//sort,filter,square
		System.out.println();
		list.stream().sorted().limit(5).map(x->x*x).forEach(x->System.out.print(x+" "));
		System.out.println();
		Optional<Integer> max=list.stream().sorted(Collections.reverseOrder()).skip(1).findFirst();
		
		if(max.isPresent())
			System.out.println("Max:"+max.get());
		//String s=null;
		//System.out.println(s.length());
		Optional<String> s1=Optional.ofNullable(null);
		if(s1.isPresent())
			System.out.println(s1.get());
		else
			System.out.println("Empty");
		System.out.println();
		
		List<Integer> newList=Arrays.asList(10,20,30,50,20,10,40,30,20,10);
		
		List<Integer> newList2= newList.stream().sorted(Collections.reverseOrder()).collect(Collectors.toList());
		
		newList2.forEach(System.out::println);
		newList.stream().distinct().forEach(x->System.out.print(x+" "));
		
		long c=newList.stream().filter(x->x<40).count();
		System.out.println();
		System.out.println(c);
			
			
		

	}

}
