package com.verizon;

import java.util.Scanner;

public class Area {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Scanner sc=new Scanner(System.in);
		System.out.println("Enter length, breadth of rectangle:");
		int l=sc.nextInt();
		int b=sc.nextInt();
		int area=l*b;
		System.out.println("Area:"+area);*/
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter length, breadth of rectangle:");
		int l=sc.nextInt();
		int b=sc.nextInt();
		if(l>0&&b>0)
		{
			int area=l*b;
			System.out.println("Area:"+area);
		}
		else
		{
			System.out.println("Invalid numbers...");
		}
		

	}

}
