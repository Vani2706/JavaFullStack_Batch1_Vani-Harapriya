package com.verizon;

public class Batch1Tech {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(args[0]);
		System.out.println(args[1]);

	}

}
