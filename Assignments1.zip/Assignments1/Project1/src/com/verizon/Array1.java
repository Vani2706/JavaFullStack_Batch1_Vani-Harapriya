package com.verizon;

public class Array1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {2,3,4,6,5,7,1};
		int sum=0;
		//int product=1;
		for(int i=0; i<a.length;i++) {
		
			//System.out.println(a[i]);
			sum+=a[i];
			//product*=a[i];
		}
	    System.out.println("Sum:"+sum);
		//System.out.println("Product:"+product);
	    int b[]=new int[5];
	    System.arraycopy(a, 0, b, 2, 3);
	    for(int i=0;i<b.length;i++)
	    	System.out.print(b[i]+" ");
	   
	}

}
