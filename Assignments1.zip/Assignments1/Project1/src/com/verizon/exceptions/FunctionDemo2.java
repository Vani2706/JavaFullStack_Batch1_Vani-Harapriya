package com.verizon.exceptions;

public class FunctionDemo2 {

	interface Arith1<T>{
		T op(T a, T b);
	}
	
	interface Arith2{
		double getEmi(int amount);
	}
	
	public static void main(String[] args) {
		
		/*Arith1 arith2=(int a,int b)->{int c=a+b;return c;};
		System.out.println(arith2.op(4, 7));
		
		Arith1 arith3=(a,b)->(a*b);
		System.out.println(arith3.op(4, 7));
		
		Arith1 arith4=(a,b)->(a*a-b*b);
		System.out.println(arith4.op(4, 7));*/
		
		Arith1<Integer> arith2=(a,b)->(a+b);
		System.out.println(arith2.op(4, 7));
		
		Arith1<Float> arith3=(a,b)->(a-b);
		System.out.println(arith3.op(4.6f, 7.0f));
		
		Arith1<Double> arith4=(a,b)->(a*a-b*b);
		System.out.println(arith4.op(4.34, 7.89));
		

	}

}
