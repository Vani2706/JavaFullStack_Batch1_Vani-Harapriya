package com.verizon.exceptions;

import java.util.Scanner;
import java.util.Random;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.function.Predicate;
import java.util.function.Function;
public class FunctionDemo3 {

	public static void main(String[] args) {
	
		Consumer<Integer> con1=(a)->System.out.println("Square of given no:"+(a*a));
		con1.accept(5);
		
		Consumer<Double> con2=(a)->System.out.println("Discount of 10%:"+(a*0.10));
		con2.accept(98000.00);
		
		Supplier<Integer> s1=()->new Random().nextInt(100);
		System.out.println(s1.get());
		
		Predicate<Integer> p=(a)->a%2==0;
		System.out.println(p.test(3));
		System.out.println(p.test(4));
		
		
		Scanner sc=new Scanner(System.in);
		int abc=sc.nextInt();
		Function<Integer,Integer> f1=(a)->a*a*a;
		System.out.println(f1.apply(abc));
		Function<String,Integer> f2=(s)->Integer.parseInt(s);
		System.out.println(f2.apply("60")+8);
		}

}
