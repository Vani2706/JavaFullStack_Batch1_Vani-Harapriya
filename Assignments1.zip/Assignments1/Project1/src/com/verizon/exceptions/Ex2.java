package com.verizon.exceptions;

public class Ex2 {

	public static void main(String[] args) {
		int a=10;
		int b=0;
		int x[]= {3,4,5};
		
		try {
			int c=a/b;
			System.out.println(c);
			
		}
		catch(ArithmeticException e) {
			System.out.println(e);
			//e.printStackTrace();
			//System.out.println(e.getMessage());
		}
		catch(ArrayIndexOutOfBoundsException e){
			e.printStackTrace();
		}
		System.out.println("Done");

	}

}
