package com.verizon.exceptions;
import java.io.FileNotFoundException;
import java.io.FileReader;
public class Ex4 {

	public static void main(String[] args) {
		FileReader f=null;
		
		try {
			f=new FileReader("c:\\abc.txt");
			
					
		}
		
		

	}

}
