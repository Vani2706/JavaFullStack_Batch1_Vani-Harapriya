package com.verizon.exceptions;

public class DepositException extends Exception{
	DepositException(String msg){
		super(msg);
	}

}
