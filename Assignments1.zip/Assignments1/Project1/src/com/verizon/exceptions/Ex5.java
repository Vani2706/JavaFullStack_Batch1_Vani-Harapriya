package com.verizon.exceptions;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class Ex5 {

	public static void main(String[] args) {
		//try with resource
		try(FileReader f= new FileReader("c:\\abc.txt");){
			
		}
		catch(FileNotFoundException e){
			
		}

	}

}
