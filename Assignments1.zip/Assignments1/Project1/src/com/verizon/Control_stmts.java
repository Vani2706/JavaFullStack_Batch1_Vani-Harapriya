package com.verizon;

import java.util.Scanner;

public class Control_stmts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*int x=0;
		while(x<=10) {
			x+=2;
			if(x==4)
				continue;
			System.out.println(x);}*/
	             
		/*for(int i=0;i<=10;i+=2)
			System.out.println(i);*/
		
		System.out.println("Choose operations, 2 numbers +, -, * , /");
		Scanner sc=new Scanner(System.in);
		char ch=sc.next().charAt(0);
		int a=sc.nextInt();
		int b=sc.nextInt();
		
		switch(ch)
		{
		case '+': {System.out.println("Sum="+(a+b));
		            break;
		          }
		case '-': {System.out.println("Sub="+(a-b));
                   break;
                  }
		case '*': {System.out.println("Pro="+(a*b));
                   break;
                  }
		case '/': {System.out.println("Div="+(a/b));
                  break;
                  }
		default: System.out.println("Wrong operator...");
		}
		
		}

}
