package com.verizon;
import java.util.Scanner;
import java.util.StringTokenizer;
public class StringDemo {

	public static void main(String[] args) {
	/*String name="Verizon Developer";//literal
	String name123= "Verizon Developer";//object
	String name1=new String("Java Developer");//object
	System.out.println(name.length());
	System.out.println(name.toLowerCase());
	System.out.println(name.concat("hyd"));
	System.out.println(name.charAt(2));
	name.replace('e','f');
	System.out.println(name.indexOf("e"));
	System.out.println(name.compareTo(name123));
	System.out.println(name.equals(name123));
	System.out.println(name==name123);
	
	char city[]= {'h','y','d'};
	String citys=new String(city);
	
	Scanner sc=new Scanner(System.in);
	String comments=sc.nextLine();
	System.out.println(comments);
	String tokens[]=comments.split(" ");
	//more iterations
	for(int i=0;i<tokens.length;i++)
		System.out.println(tokens[i]);
	
	//enhanced for loop
	for(String x:tokens)
		System.out.println(x);*/
	
	
	
	/*//String Buffer
	StringBuffer sb= new StringBuffer("Javatechnology");
	sb.append(1999);
	System.out.println(sb);
	System.out.println(sb.insert(3, "xxxx"));
	System.out.println(sb.delete(3, 8));
	sb.ensureCapacity(50);
	System.out.println(sb.reverse());
	System.out.println(sb.capacity());*/
	
	//String Builder
	String ss= "javatechnology";
	StringBuilder sb= new StringBuilder(ss);
	String sss=sb.toString();
	System.out.println(sb.capacity());
	sb.append(8787);
	System.out.println(sb.insert(3, "xxxx"));
	sb.ensureCapacity(50);
	System.out.println(sb.capacity());
	System.out.println(sb.delete(3,8));
	System.out.println(sb.reverse());
	String line="Verizon,BuildNo10,RahejaMindSpace,Hyderabad,Telangana,India";
	StringTokenizer st=new StringTokenizer(line,",");
	System.out.println(st.countTokens());
	while(st.hasMoreTokens())
		System.out.println(st.nextToken());
	
	}

}
