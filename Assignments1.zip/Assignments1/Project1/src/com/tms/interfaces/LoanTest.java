package com.tms.interfaces;

public class LoanTest {
	
	public static void main(String[] args) {
		
		//Loan l;  refference for Loan(parent) class
		//HousingLoan h1= new HousingLoan();  object creation for Housing(sub class) loan
		//l=h1    now you can access
		
		Loan l;
		HousingLoan h1=new HousingLoan();
		l=h1;
		l.applyLoan("ram", 20000.00);
		l.submitDocs();
		System.out.println(l.getEmi());
		Surity s1;
		s1=h1;
		s1.submitDocs2();
		
		VehicleLoan v1=new VehicleLoan();
		s1=v1;
		l=new VehicleLoan();
		l.applyLoan("raj", 10000.00);
		l.submitDocs();
		System.out.println(l.getEmi());
		s1.submitDocs2();
		
		
	}

}
