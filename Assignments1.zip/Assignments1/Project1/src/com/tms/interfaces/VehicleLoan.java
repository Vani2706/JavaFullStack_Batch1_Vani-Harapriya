package com.tms.interfaces;

public class VehicleLoan implements Loan,Surity,Parking{
	public void applyLoan(String name, double amount) {
		System.out.println(name+" loan of amount Rs "+amount+" applied");
		
	}
    public void submitDocs() {
    	System.out.println("vehicle docs are submitted");
    	
    }
	public int getEmi() {
		return 899;
	}
	public void submitDocs2() {
		
	}
	public void getSlot() {
		
	}

}
