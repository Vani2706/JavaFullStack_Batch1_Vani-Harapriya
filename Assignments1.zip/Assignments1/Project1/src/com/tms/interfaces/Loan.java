package com.tms.interfaces;

interface Loan { //all the variables and methods should be abstract and public
	

	void applyLoan(String name, double amount);
	void submitDocs();
	int getEmi();
	
}
