package com.tms.interfaces;

interface Surity {
	void submitDocs2();

}
