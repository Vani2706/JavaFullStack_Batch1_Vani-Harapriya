package com.tms.polymorphisms;

public class Mload {
	void area(int s) {
		System.out.println("Square:"+(s*s));
	}
	void area(int l, int b) {
		System.out.println("Rectangle:"+(l*b));
	}
	void area(double r) {
		System.out.println("Circle:"+(3.14*r*r));
	}
	public static void main(String[] args) {
		Mload m=new Mload();
		m.area(6);
		m.area(4, 4);
		m.area(2.0);
	}

}
