package com.tms.polymorphisms;

public class Mride extends Ride{
	@Override
	void sq(int s) {
		System.out.println("Perimeter:"+(4*s));
	
	}
	public static void main(String[] args) {
		Mride m=new Mride();
		m.sq(6);
		Ride r=new Mride();
		r.sq(6);
		r=new Ride();
		r.sq(6);;
	}
}