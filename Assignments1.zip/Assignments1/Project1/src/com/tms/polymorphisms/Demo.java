package com.tms.polymorphisms;


public class Demo {
	static {
		System.out.println("Hello...this is a static block");
	}
	//Converting primitive datatypes to objects
	public static void main(String[] args) {
		String age="30";
		int x=Integer.parseInt(age);
		System.out.println(x);
		double y=Double.parseDouble(age);
		System.out.println(y);

		// Type Casting
		int d= 65;
		double d1=d;   //implicit type casting
		System.out.println(d1);
		
		double b=45673459.87;
		int b1=(int)b;  //explicit type casting
		System.out.println(b1);
		
		
		
	}

}
