package com.tms.polymorphisms;

public class Ride {
	void sq(int s) {
		System.out.println("Area of sq:"+(s*s));

}
}
