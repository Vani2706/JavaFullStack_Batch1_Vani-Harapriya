package com.tms.polymorphisms;

public class Mride1 extends Mride{

	
		@Override
		void sq(int s) {
			System.out.println("Cube area:"+(s*s*s));

	}
		public static void main(String[] args) {
		Mride1 p = new Mride1();
		p.sq(6);
		Mride r=new Mride1();
		r=new Mride();
		r.sq(6);	
		Ride w= new Mride1();
		w=new Ride();
		w.sq(6);
		
		
	}
}
