package com.tms.abstraction;

public class LoanTest {
	
	public static void main(String[] args) {
		
		//Loan l;  reference for Loan(parent) class
		//HousingLoan h1= new HousingLoan();  object creation for Housing(sub class) loan
		//l=h1    now you can access
		
		Loan l=new HousingLoan();
		l.applyLoan("ram", 20000.00);
		l.submitDocs();
		System.out.println(l.getEmi());
		
		l=new VehicleLoan();
		l.applyLoan("raj", 10000.00);
		l.submitDocs();
		System.out.println(l.getEmi());
		
	}

}
