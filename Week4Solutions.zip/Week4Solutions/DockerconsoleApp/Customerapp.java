class Customerapp {
String name;
Customerapp(String name){
this.name=name;
}
void displayCustomer(){
System.out.println("Customer:"+this.name);
}
public static void main( String args[]) {
Customerapp c=new Customerapp("Harry");
c.displayCustomer();
 }
}
